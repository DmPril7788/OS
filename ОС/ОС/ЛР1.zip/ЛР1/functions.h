#include <stdio.h>

int EnterBid (int b,int money);
void PrintResult(int b, int money);