#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "functions.h"
void PrintResult(int b, int money){

	printf ("Ваш выигрыш составляет = %d\n", b);
	printf ("Ваш баланс = %d\n", money); 
}