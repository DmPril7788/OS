#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "functions.h"
int EnterBid (int b,int money){
	do{
	printf ("Введите свою ставку:");
	scanf ("%d", &b);
	if (b>money)
	{
	printf ("---------WARNING---------\n");
	printf ("У вас не хватает денег на счету\n"); 

	}
	else{
	if (b<1){
	printf ("---------WARNING---------\n");
	printf ("Вы должны ввести сумму больше 1 доллара\n");
	}
	}
} while (b>money || b<1);
return b; 
}