#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

// kill -s SIGUSR1 3422

/* Handler for SIGINT */
static void signal_haldler(int signo) {
	if (signo == SIGINT) {
		printf("Catched signal SIGINT\n");
	} else if (signo == SIGTERM) {
		printf("Catched signal SIGTERM\n");
	} else if (signo == SIGUSR1){
		printf("Catched signal SIGUSR1\n");
		exit(EXIT_SUCCESS);
	} else {
		fprintf(stderr, "Wrong Signal\n");
		exit(EXIT_FAILURE);
	}
	//exit(EXIT_SUCCESS);
}

int main(void) {
	setbuf(stdout, NULL);
	printf("PID: %d\n", (int)getpid());
	/* Let register signal_handler as handler for SIGINT */
	if (signal(SIGINT, signal_haldler) == SIG_ERR) {
		fprintf(stderr, "It is impossible to handle SIGINT!\n");
		exit(EXIT_FAILURE);
	}
	/* Let register signal_handler as handler for SIGTERM */
	if (signal(SIGTERM, signal_haldler) == SIG_ERR) {
		fprintf(stderr, "It is impossible to handle SIGTERM!\n");
		exit(EXIT_FAILURE);
	}
	/* Восстановление поведения по умолчанию для сигнала SIGPROF */
	if (signal(SIGPROF, SIG_DFL) == SIG_ERR) {
		fprintf(stderr, "It is impossible to reset SIGPROF!\n");
		exit(EXIT_FAILURE);
	}
	/* Игнорировать сигнал SIGHUP */
	if (signal(SIGHUP, SIG_IGN) == SIG_ERR) {
		fprintf(stderr, "It is impossible to ignore SIGHUP!\n");
		exit(EXIT_FAILURE);
	}
	/* Let register signal_handler as handler for SIGUSR1 */
	if (signal(SIGUSR1, signal_haldler) == SIG_ERR) {
		fprintf(stderr, "It is impossible to handle SIGUSR1!\n");
		exit(EXIT_FAILURE);
	}
	
	while(1) {
		printf("The process is waiting for signal\n");
		pause();
	}
		
	fprintf(stderr, "The program is finished\n");
	
	return EXIT_SUCCESS;
}