//Without sleep
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

#define SIGNAL_COUNT 10

extern const char * const sys_siglist[];

void sighand(int signo, siginfo_t *info, void *extra)
{
	if(signo == SIGTERM)
	{
		fprintf(stderr, "\t\tProcess %d get TERM signal\n", getpid());
		exit(EXIT_SUCCESS);
	}
	else
		fprintf(stdout, "\t\tPID: %d, signal: %s, value: [%d]\n", getpid(), sys_siglist[signo], info->si_value.sival_int);
}

int main(void)
{	
	sigset_t mask_block, mask_get;
	struct sigaction action;

	setbuf(stdout, NULL);	
	
	sigemptyset(&mask_block);
	sigaddset(&mask_block, SIGUSR1);
	
	sigfillset(&mask_get);
	sigdelset(&mask_get, SIGUSR1);
	sigdelset(&mask_get, SIGINT);
	sigdelset(&mask_get, SIGTERM); 

	
	sigfillset(&action.sa_mask); 
	action.sa_flags = SA_SIGINFO;
	action.sa_sigaction = sighand;

	sigaction(SIGUSR1, &action, NULL);
	sigaction(SIGTERM, &action, NULL);

	sigprocmask(SIG_BLOCK, &mask_block, NULL);

	pid_t child_pid = fork();

	if(child_pid == 0)
	{
		
		while(1)
		{
			sigqueue(getppid(), SIGUSR1, (const union sigval) NULL);
			//pause();
			printf("\tChild process %d wait signal\n", getpid());
			sigsuspend(&mask_get);
		}
	}
	else
	{
		int i, status;
		union sigval v;
		//sleep(5);
		for(i = 0; i < SIGNAL_COUNT; i++)
		{
			sigsuspend(&mask_get);
			v.sival_int = i;
			int res = sigqueue(child_pid, SIGUSR1, v);
			//sleep(1);
			fprintf(stderr, "Signal %d to %d is send\n", i, child_pid);
		}
		sigqueue(child_pid, SIGTERM, (const union sigval) NULL); // EXIT SIGNAL
		wait(&status);
		fprintf(stdout, "Parent PID: %d, Child PID: %d\n", getpid(), child_pid);
	}
	// sigprocmask(SIG_SETMASK, &old_mask, NULL);
	
	return EXIT_SUCCESS;
}