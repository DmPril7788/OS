#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>


/* Handler for SIGINT and SIGTERM */
static void signal_haldler(int signo) {
	//psignal(signo, "Signal nas been received");
	printf("Sigmal No %d (%s) has been received.\n", 
		signo, strsignal(signo));
	if (signo == SIGUSR1) exit(EXIT_SUCCESS);
}

int main(void) {
	static struct sigaction act;
	
	setbuf(stdout, NULL);
	printf("PID: %d\n", (int)getpid());
	
	act.sa_handler = signal_haldler;
	sigfillset(&act.sa_mask);   // It is non neccessary
    act.sa_flags = SA_RESTART;  // It is non neccessary	
	
	/* Let register signal_handler as handler for SIGINT */
	if (sigaction(SIGINT, &act, NULL) == -1) {
		fprintf(stderr, "It is impossible to handle SIGINT!\n");
		exit(EXIT_FAILURE);
	}
	/* Let register signal_handler as handler for SIGTERM */
	if (sigaction(SIGTERM, &act, NULL) == -1) {
		fprintf(stderr, "It is impossible to handle SIGTERM!\n");
		exit(EXIT_FAILURE);
	}
	
	/* Let register signal_handler as handler for SIGUSR1 */
	if (sigaction(SIGUSR1, &act, NULL) == -1) {
		fprintf(stderr, "It is impossible to handle SIGUSR1!\n");
		exit(EXIT_FAILURE);
	}
	
	/* Восстановление поведения по умолчанию для сигнала SIGPROF */
	act.sa_handler = SIG_DFL;
	if (sigaction(SIGPROF, &act, NULL) == -1) {
		fprintf(stderr, "It is impossible to reset SIGPROF!\n");
		exit(EXIT_FAILURE);
	}
	/* Игнорировать сигнал SIGHUP */
	act.sa_handler = SIG_IGN;
	if (sigaction(SIGHUP, &act, NULL) == -1) {
		fprintf(stderr, "It is impossible to ignore SIGHUP!\n");
		exit(EXIT_FAILURE);
	}
	
	while(1) {
		printf("The process is waiting for signal\n");
		pause();
	}		
	fprintf(stderr, "The program is finished\n");
	
	return EXIT_SUCCESS;
}