/* Example of kill function */

#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

sig_atomic_t ntimes = 0;

int main(void) {
	pid_t pid, ppid;
	void parent_action(int), child_action(int);
	static struct sigaction parent_act, child_act;
	
	/* Define handler of signal SIGUSR1 in parent process */
	parent_act.sa_handler = parent_action;
	sigfillset(&parent_act.sa_mask);   // It is non neccessary
	sigdelset(&parent_act.sa_mask, SIGUSR1);  // It is non neccessary
	parent_act.sa_flags = SA_RESTART;  // It is non neccessary
	sigaction(SIGUSR1, &parent_act, NULL);
	
	switch(pid = fork()) {
	case -1: /* Error */
		perror("task2");
		exit(EXIT_FAILURE);
	
	case 0: /* Child Process */
	/* Define handler of signal SIGUSR1 in parent process */
		child_act.sa_handler = child_action;
		sigfillset(&child_act.sa_mask);   // It is non neccessary
        sigdelset(&child_act.sa_mask, SIGUSR1);  // It is non neccessary
        child_act.sa_flags = SA_RESTART;  // It is non neccessary
		sigaction(SIGUSR1, &child_act, NULL);
		/* get parent process id */
		ppid = getppid();
		
		/* Infinite loop */
		for(;;) {
			sleep(1);  //Deadlock without sleep
			kill(ppid, SIGUSR1);
			pause();
		}
		
	default: /* Parent Process */
		/* Infinite loop */
		for(;;) {
			pause();
			sleep(1); //Deadlock without sleep
			kill(pid, SIGUSR1);
		}
	}
	return EXIT_SUCCESS;
}

/* ============================== */

void parent_action(int sig) {
	printf("Parent process get signal #%d\n", ++ntimes);
}

void child_action(int sig) {
	printf("Child process get signal #%d\n", ++ntimes);
}