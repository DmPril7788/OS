#ifndef SOLVE_H_
#define SOLVE_H_

void solve(double a, double b, double c, double *x1, double *x2, int *t);

#endif
